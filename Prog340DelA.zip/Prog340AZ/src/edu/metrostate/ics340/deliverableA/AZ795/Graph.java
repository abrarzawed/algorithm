package edu.metrostate.ics340.deliverableA.AZ795;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Graph {
	private static final String DEFAULT = "";
	private BufferedReader br1;
	private BufferedReader br2;
	private BufferedReader br3;
	private String currentLine;
	private String output = "";
	private String graphFile;
	private File file;
	private String newCurrentLine;
	private String tempNodeName;
	private String nodeName;
	private String tempNodeMnemonic;
	private String nodeMnemonic;
	private String nodeValue;
	private ArrayList<Node> list;

	public Graph(File inputFileName) {
		list = new ArrayList<Node>();
		readFile(inputFileName);
	}

	private void readFile(File NewFileName) {
		Scanner sc;
		String name = "";
		String val = "";
		String temp = "";
		int num = 0;
		ArrayList<String> row = new ArrayList<String>();
		ArrayList<String> vertex = new ArrayList<String>();
		ArrayList<String> names = new ArrayList<String>();
		ArrayList<String> columns = new ArrayList<String>();

		try {
			// reading the 1st row
			br1 = new BufferedReader(new FileReader(NewFileName));
			while ((currentLine = br1.readLine()) != null) {
				sc = new Scanner(currentLine);
				names.add(sc.next());
				sc.next();
				columns.add(sc.next());

			}

			br1 = new BufferedReader(new FileReader(NewFileName));
			currentLine = br1.readLine();
			sc = new Scanner(currentLine);
			sc.next();
			sc.next();
			while ((temp = sc.next()) != null) {
				row.add(temp);

				if (!sc.hasNext()) {
					break;
				}
			}

			// Subsequent rows after the 1st row

			while ((currentLine = br1.readLine()) != null) {

				sc = new Scanner(currentLine);
				name = sc.next();
				val = sc.next();
				while ((temp = sc.next()) != null) {

					vertex.add(temp);
					if (!sc.hasNext()) {
						break;
					}
				}

				output += "Node " + name + "," + " mnemonic " + row.get(num++) + "," + " value " + val + "\r\n";

				for (int i = 0; i < vertex.size(); i++) {
					if (!vertex.get(i).equals("~")) {
						output += name + " has edge to " + names.get(i + 1) + " labeled " + vertex.get(i) + "\r\n";
					}
				}
				for (int i = 1; i < columns.size(); i++) {
					if (!columns.get(i).equals("~")) {
						output += name + " has edge from " + names.get(i) + " labeled " + columns.get(i) + "\r\n";
					}
				}

				output += "\r\n";
				vertex.clear();
				columns.clear();
				br2 = new BufferedReader(new FileReader(NewFileName));
				while ((currentLine = br2.readLine()) != null) {
					sc = new Scanner(currentLine);
					names.add(sc.next());
					sc.next();
					for (int i = 0; i < num; i++) {
						sc.next();
					}
					if (sc.hasNext()) {
						columns.add(sc.next());
					}
				}

			}
			graphFile = "FileToRead";
			file = new File(graphFile);
			PrintWriter pw = new PrintWriter(file);
			pw.write(output);
			pw.close();
			readGraphedFile(file);
			file.deleteOnExit();

		} catch (Exception error) {
			error.printStackTrace();
		}

	}

	// reads the graphed file and creates node object with 3 parameters
	// later may be needed to create edge objects
	private void readGraphedFile(File newFiles) {
		try {

			Scanner sc1;
			br3 = new BufferedReader(new FileReader(newFiles));
			while ((newCurrentLine = br3.readLine()) != null) {
				if (newCurrentLine.length() > 0) {
					sc1 = new Scanner(newCurrentLine);
					if (sc1.next().equals("Node")) {
						tempNodeName = sc1.next();
						nodeName = tempNodeName.substring(0, tempNodeName.length() - 1);
						

						sc1.next();
						tempNodeMnemonic = sc1.next();
						nodeMnemonic = tempNodeMnemonic.substring(0, tempNodeMnemonic.length() - 1);
		

						sc1.next();
						nodeValue = sc1.next();
						list.add(new Node(nodeName, nodeMnemonic, nodeValue));
					}

				}
			}
			// for testing purpose
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).getName());
				System.out.println(list.get(i).getMnemonic());
				System.out.println(list.get(i).getVal());
				System.out.println();
			}
			

		} catch (Exception error) {
			error.printStackTrace();
		}

	}

	public String getOutput() {
		return this.output;
	}

	public ArrayList<Node> getArrayList() {
		return this.list; // CHECK HERE
	}

	public void setDefaultOutput() {
		this.output = DEFAULT;
	}

}
