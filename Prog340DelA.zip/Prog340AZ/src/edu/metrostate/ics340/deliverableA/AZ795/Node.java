package edu.metrostate.ics340.deliverableA.AZ795;

public class Node {
	private String name;
	private String mnemonic;
	private String val;
	
	
	public Node(String name, String mnemonic, String val) {
		this.name = name;
		this.mnemonic = mnemonic;
		this.val = val;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMnemonic() {
		return mnemonic;
	}


	public void setMnemonic(String mnemonic) {
		this.mnemonic = mnemonic;
	}


	public String getVal() {
		return val;
	}


	public void setVal(String val) {
		this.val = val;
	}

}
