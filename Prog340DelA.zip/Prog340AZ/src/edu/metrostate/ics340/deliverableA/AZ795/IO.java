package edu.metrostate.ics340.deliverableA.AZ795;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class IO {
	private String outputFileName;

	public IO(File inputFileName, Graph g) {
		displayOutput(inputFileName, g);
		
	}

	private void displayOutput(File inputFileName, Graph g) {
		outputFileName = inputFileName.getAbsolutePath().substring(0, inputFileName.getAbsolutePath().lastIndexOf('.'));
		outputFileName += "_out.txt";
		try {
			PrintWriter pw = new PrintWriter(new File(outputFileName));
			System.out.println(outputFileName + " is created");
			pw.write(g.getOutput());
			g.setDefaultOutput();
			pw.close();
		} catch (FileNotFoundException e) {
			System.out.println("File is not found");
			e.printStackTrace();
		}
		
	}

}

