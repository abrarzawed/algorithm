package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.io.File;
import java.util.ArrayList;

/**
 * Class that creates a Min-Heap using an ArrayList of Nodes
 * 
 * @author Abrar Zawed
 */

public class Heap {

	private ArrayList<Node> nodeList;
	private ArrayList<Node> tempNodeList;
	private HeapSort heapSort;

	/**
	 * Constructor that creates a Min_heap
	 * 
	 * @param inputFileName
	 *            - The original ungraphed file
	 * @param g
	 *            - Graph object
	 */
	public Heap(File inputFileName, Graph g) {

		// Min-Heap
		System.out.println("Heaps: ");
		System.out.println();

		this.tempNodeList = new ArrayList<>();
		this.nodeList = g.getArrayList();
		for (int i = 0; i < nodeList.size(); i++) {
			heapInsert(nodeList.get(i));
			buildHeap();
			printHeap(tempNodeList);
		}

		// Heap Sort
		System.out.println("Heapsort: ");
		System.out.println();
		heapSort = new HeapSort(tempNodeList);

	}

	/**
	 * Method that inserts a Node to the Heap
	 * 
	 * @param item
	 *            - Node object
	 */
	public void heapInsert(Node item) {
		int i = tempNodeList.size();
		tempNodeList.add(item);
		int parent = parent(i);
		while (parent != -1 && Integer.parseInt(tempNodeList.get(i).getVal()) < Integer
				.parseInt(tempNodeList.get(parent).getVal())) {
			swap(i, parent);
			i = parent;
			parent = parent(i);
		}
	}

	/**
	 * Method that prints a min-heaped Nodes
	 * 
	 * @param listNode
	 *            - min-heaped Nodes
	 */
	private void printHeap(ArrayList<Node> listNode) {
		for (int i = 0; i < listNode.size(); i++) {
			if (i != listNode.size() - 1) {
				System.out.print((i + 1) + ":" + (listNode.get(i)) + ", ");
			} else {
				System.out.print((i + 1) + ":" + (listNode.get(i)) + " ");
			}
		}
		System.out.println("\n");

	}

	/**
	 * Method that builds a heap
	 */
	private void buildHeap() {
		for (int i = (int) (tempNodeList.size() / 2); i >= 0; i--) {
			heapify(i);
		}
	}

	/**
	 * Method that min-heaps an ArrayList of Nodes
	 * 
	 * @param i
	 */
	private void heapify(int i) {
		int l = left(i);
		int r = right(i);
		int smallest = i;
		if (l < tempNodeList.size()
				&& Integer.parseInt(tempNodeList.get(l).getVal()) < Integer.parseInt(tempNodeList.get(i).getVal())) {
			smallest = l;
		}
		if (r < tempNodeList.size() && Integer.parseInt(tempNodeList.get(r).getVal()) < Integer
				.parseInt((tempNodeList.get(smallest).getVal()))) {
			smallest = r;
		}
		if (smallest != i) {
			swap(i, smallest);
			heapify(smallest);
		}
	}

	/**
	 * Method that exchanges two Node object
	 * 
	 * @param i1
	 *            - Node Object
	 * @param i2
	 *            - Node Object
	 */
	private void swap(int i1, int i2) {
		Node temp = tempNodeList.get(i1);
		tempNodeList.set(i1, tempNodeList.get(i2));
		tempNodeList.set(i2, temp);
	}

	/**
	 * Parent of the Node in action
	 * 
	 * @param i
	 * @return - the position of the parent Node
	 */
	private int parent(int i) {
		if (i == 0) {
			return -1;
		}
		return (i - 1) / 2;
	}

	/**
	 * Left child of the Node in action
	 * 
	 * @param i
	 * @return - the position of the left child Node
	 */
	private int left(int i) {
		return 2 * i + 1;
	}

	/**
	 * Right child of the Node in action
	 * 
	 * @param i
	 * @return - the position of thright child Node
	 */
	private int right(int i) {
		return 2 * i + 2;
	}

	/**
	 * Method that extract the Min Node from a heap
	 * @return
	 */
	public Node extractMin() {
		if (tempNodeList.size() == 0) {
			return null;
		}
		if (tempNodeList.size() == 1) {
			return tempNodeList.remove(0);
		}
		Node min = tempNodeList.get(0);
		Node last = tempNodeList.remove(tempNodeList.size() - 1);
		tempNodeList.set(0, last);
		heapify(0);
		return min;
	}

	/**
	 * Method that returns that Node with minimum value
	 * Does not removes from the heap
	 * @return
	 */
	public Node min() {
		if (tempNodeList.size() == 0) {
			return null;
		}
		return tempNodeList.get(0);
	}

	/**
	 * Method that clears the heap
	 */
	public void clear() {
		tempNodeList.clear();
	}

	/**
	 * Method that checks if a heap is empty
	 * @return
	 */
	public boolean isEmpty() {
		return tempNodeList.size() == 0;
	}

	/**
	 * Method that returns the size of a heap in terms of Nodes
	 * @return
	 */
	public int size() {
		return tempNodeList.size();
	}

}
