package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class graphs a .txt file and creates Nodes and Edges with suitable
 * parameters
 * 
 * @author Abrar Zawed
 */
public class Graph {
	private static final String DEFAULT = "";
	private BufferedReader br1;
	private BufferedReader br2;
	private String currentLine;
	private String output = "";
	private Scanner sc;
	private String name = "";
	private String val = "";
	private String temp = "";
	private int num = 0;
	private String mnemonic = "";
	private ArrayList<Node> list;
	private ArrayList<String> row;
	private ArrayList<String> vertex;
	private ArrayList<String> names;
	private ArrayList<String> columns;

	/**
	 * Constructor that graphs a text file
	 * 
	 * @param inputFileName
	 *            -> .txt file
	 */
	public Graph(File inputFileName) {
		list = new ArrayList<Node>();
		readFile(inputFileName);
	}

	/**
	 * Method that reads a .txt file
	 * 
	 * @param NewFileName
	 *            -> input .txt file
	 */
	private void readFile(File NewFileName) {

		row = new ArrayList<String>();
		vertex = new ArrayList<String>();
		names = new ArrayList<String>();
		columns = new ArrayList<String>();

		try {
			br1 = new BufferedReader(new FileReader(NewFileName));
			while ((currentLine = br1.readLine()) != null) {
				sc = new Scanner(currentLine);
				names.add(sc.next());
				sc.next();
				columns.add(sc.next());

			}

			br1 = new BufferedReader(new FileReader(NewFileName));
			currentLine = br1.readLine();
			sc = new Scanner(currentLine);
			sc.next();
			sc.next();
			while ((temp = sc.next()) != null) {
				row.add(temp);

				if (!sc.hasNext()) {
					break;
				}
			}

			while ((currentLine = br1.readLine()) != null) {

				sc = new Scanner(currentLine);
				name = sc.next();
				val = sc.next();
				while ((temp = sc.next()) != null) {

					vertex.add(temp);
					if (!sc.hasNext()) {
						break;
					}
				}
				mnemonic = row.get(num++);

				// creating Node object Node(String name, String mnemonic,
				// String value);
				// May need to subclass it in future to add which edges that are
				// going to and from the Node

				list.add(new Node(name, mnemonic, val));

				output += "Node " + name + "," + " mnemonic " + mnemonic + "," + " value " + val + "\r\n";

				for (int i = 0; i < vertex.size(); i++) {
					if (!vertex.get(i).equals("~")) {
						output += name + " has edge to " + names.get(i + 1) + " labeled " + vertex.get(i) + "\r\n";
					}
				}
				for (int i = 1; i < columns.size(); i++) {
					if (!columns.get(i).equals("~")) {
						output += name + " has edge from " + names.get(i) + " labeled " + columns.get(i) + "\r\n";
					}
				}

				output += "\r\n";
				vertex.clear();
				columns.clear();
				br2 = new BufferedReader(new FileReader(NewFileName));
				while ((currentLine = br2.readLine()) != null) {
					sc = new Scanner(currentLine);
					names.add(sc.next());
					sc.next();
					for (int i = 0; i < num; i++) {
						sc.next();
					}
					if (sc.hasNext()) {
						columns.add(sc.next());
					}
				}

			}

		} catch (Exception error) {
			error.printStackTrace();
		}

	}

	/**
	 * Returns -> String named output that is used in the IO class for
	 * PrintWriter
	 * 
	 * @return String named output that is used in the IO class for PrintWriter
	 */
	public String getOutput() {
		return this.output;
	}

	/**
	 * Returns -> an ArrayList of Node object which was used in the Heap class
	 * to create min-heap
	 * 
	 * @return
	 */
	public ArrayList<Node> getArrayList() {
		return this.list;
	}

	/**
	 * Method that clears the output string for next next .txt file
	 */
	public void setDefaultOutput() {
		this.output = DEFAULT;
	}

}
