package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.util.ArrayList;

/**
 * Class that sorts an ArrayList of Node objects into decreasing order using min-heap
 * 
 * @author Abrar Zawed
 */
public class HeapSort {

	private ArrayList<Node> heapNode;
	private Node[] nodes;

	public HeapSort(ArrayList<Node> tempNodeList) {
		this.heapNode = tempNodeList;
		nodes = heapNode.toArray(new Node[heapNode.size()]);

		minSort(nodes);

	}

	/**
	 * Methods that sorts an ArrayList of Node objects into decreasing order using min-heap 
	 * @param nodesArrays -> ArrayList of Nodes
	 */
	private void minSort(Node[] nodesArrays) {
		int heapSize = nodesArrays.length;
		buildHeap(nodesArrays, heapSize);
		while (heapSize > 1) {
			swap(nodesArrays, 0, heapSize - 1);
			heapSize--;
			heapify(nodesArrays, heapSize, 0);
			for (int i = 0; i < nodesArrays.length; i++) {
				if (i != nodesArrays.length - 1) {
					System.out.print((i + 1) + ":" + nodesArrays[i].getMnemonic() + ", ");
				} else {
					System.out.print((i + 1) + ":" + nodesArrays[i].getMnemonic() + " ");
				}
			}
			System.out.println("\n");
		}

	}

	/**
	 * Method that builds a min-heap
	 * @param array - Array of Node objects
	 * @param heapSize - size of the array
	 */
	private void buildHeap(Node[] array, int heapSize) {
		for (int i = (int) (array.length / 2); i >= 0; i--) {
			heapify(array, heapSize, i);
		}
	}

	/**
	 * Heapify an array of Nodes
	 * @param array Array of Node objects
	 * @param heapSize size of the array
	 * @param i - a specific nodes from the array
	 */
	private void heapify(Node[] array, int heapSize, int i) {
		int left = this.left(i);
		int right = this.right(i);
		int smallest;
		if (left < heapSize && Integer.parseInt(array[left].getVal()) < Integer.parseInt((array[i]).getVal()))
			smallest = left;
		else
			smallest = i;
		if (right < heapSize && Integer.parseInt(array[right].getVal()) < Integer.parseInt((array[smallest]).getVal()))
			smallest = right;
		if (smallest != i) {
			swap(array, i, smallest);
			heapify(array, heapSize, smallest);
		}

	}

	/**
	 * Exchanges two Node object
	 * @param - array Array of Node objects
	 * @param a - Node
	 * @param b - Node
	 */
	private void swap(Node[] array, int a, int b) {
		Node temp = array[a];
		array[a] = array[b];
		array[b] = temp;

	}

	/**
	 * Parent of the Node in action
	 * @param i
	 * @return - the position of the parent Node
	 */
	@SuppressWarnings("unused")
	private int parent(int i) {
		if (i == 0) {
			return -1;
		}
		return (i - 1) / 2;
	}

	/**
	 * Left child of the Node in action
	 * @param i
	 * @return - the position of the left child Node
	 */
	private int left(int i) {
		return 2 * i + 1;
	}

	/**
	 * Right child of the Node in action
	 * @param i
	 * @return - the position of the right child Node
	 */
	private int right(int i) {
		return 2 * i + 2;
	}

}
