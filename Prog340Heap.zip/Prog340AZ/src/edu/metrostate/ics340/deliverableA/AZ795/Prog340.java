package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * This program will read a text file, graph it, and finally write the output in
 * the same directory from which the program was executed
 * 
 * @author Abrar Zawed
 * @date 18th Jan 2018 
 * @date 8th Feb, 2018
 * 		 Acknowledgments:
 *       https://stackoverflow.com/questions/14306125/how-to-use-actionlistener-on-a-combobox-to-give-a-variable-a-value
 *       https://github.com/gwtw/growing-with-the-web/blob/master/src/com/growingwiththeweb/datastructures/BinaryHeap.java
 *       https://github.com/gwtw/java-sorting/blob/master/src/com/growingwiththeweb/sorting/Heapsort.java
 */

public class Prog340 {

	private JFrame frame;
	private JFileChooser fileChooser;
	private File inputFileName;
	private File workingDirectory;
	private int returnVal;
	private JComboBox<String> actionItems;
	private Graph g;

	/**
	 * Constructor that implements deliverables
	 * Deliverables: I/O, Heap, Mist, Sale1, Sale2, Consat
	 */
	public Prog340() {
		setComboBoxAndReadFile();
	}

	/**
	 * Method that is used to set-up the GUI and then, reads .txt files
	 * @return void
	 */
	private void setComboBoxAndReadFile() {
		frame = new JFrame("ICS 340");
		frame.setPreferredSize(new Dimension(250, 70));
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		fileChooser = new JFileChooser();
		workingDirectory = new File(System.getProperty("user.dir"));
		fileChooser.setCurrentDirectory(workingDirectory);

		actionItems = new JComboBox<String>();
		actionItems.addItem("Select");
		actionItems.addItem("Read and Graph");
		actionItems.addItem("I/O");
		actionItems.addItem("Heap");
		actionItems.addItem("Mist");
		actionItems.addItem("Sale1");
		actionItems.addItem("Sale2");
		actionItems.addItem("Consat");
		actionItems.addItem("Exit");
		actionItems.setSelectedIndex(0);
		ActionListener cbActionListener = new ActionListener() {
			@SuppressWarnings("unused")
			public void actionPerformed(ActionEvent e) {
				int itemInt = (int) actionItems.getSelectedIndex();

				switch (itemInt) {
				case 1:
					returnVal = fileChooser.showOpenDialog(null);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						inputFileName = fileChooser.getSelectedFile();
					}
					g = new Graph(inputFileName);
					break;
				case 2:
					IO io = new IO(inputFileName, g);
					break;
				case 3:
					Heap heap = new Heap(inputFileName, g);
					break;
				case 4:
					System.out.println("Mist to be implemented");
					break;
				case 5:
					System.out.println("Sale1 to be implemented");
					break;
				case 6:
					System.out.println("Sale2 to be implemented");
					break;
				case 7:
					System.out.println("Consat to be implemented");
					break;
				case 8:
					System.out.println("Goodbye");
					System.exit(0);
				default:
					System.out.println("Invalid Choice");
					System.exit(0);
				}

			}
		};
		actionItems.addActionListener(cbActionListener);
		frame.add(actionItems);
		frame.pack();
		frame.setVisible(true);

	}

	/**
	 * Main method the starts the program
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Prog340();
			}
		});

	}
}