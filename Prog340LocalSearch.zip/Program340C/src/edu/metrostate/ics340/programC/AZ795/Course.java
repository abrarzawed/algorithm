package edu.metrostate.ics340.programC.AZ795;
/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

/**
 * Class that creates instances of Course object
 * 
 * @author Abrar Zawed 
 * Created: April 17th 2018
**/
public class Course {
	String name;
	int semester;

	/**
	 * Constructor that creates Course object
	 * @param name
	 */
	public Course(String name) {
		this.name = name;
	}

	/**
	 * Returns the name of the course
	 * @return the name of the course
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the name of the course
	 * @param name of the course
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the semester of the course
	 * @return the semester of the course
	 */
	public int getSemester() {
		return semester;
	}
	/**
	 * Set the semester of the course
	 * @param semester of the course
	 */
	public void setSemester(int semester) {
		this.semester = semester;
	}

}
