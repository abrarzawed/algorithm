package edu.metrostate.ics340.programC.AZ795;
/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

/**
 * Class that implements local search
 * 
 * @author Abrar Zawed 
 * Created: April 17th 2018
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;

public class Prog340C {
	private static final int MAX_VALUE = 7;
	private static final int MIN_VALUE = 1;
	private ArrayList<Course> courses;
	private Random ran;
	private Course m120;
	private Course m210;
	private Course m215;
	private Course cs140;
	private Course cs141;
	private Course cs232;
	private Course cs240;
	private Course cs311;
	private Course cs340;
	private Course cs365;
	private Course cs372;
	private Course cs440;
	private Course cs460;
	private Course cs462;
	private Course cs490;
	private Course cs492;
	private Course cs499;
	private Course lib998;
	private Course lib999;
	private PrintWriter printVerbose;
	private PrintWriter printSummary;
	
	/**
	 * Constructor that initiates local search
	 * @throws FileNotFoundException
	 */

	public Prog340C() throws FileNotFoundException {
		
			// instantiate courses
			declareCourses();
			
			// creates text file with header line
			createTextFile();

			// local search method
			localSearch(courses);
			
			if(localSearch(courses) == true) {
				printVerbose.write("ANSWER FOUND:" + "\n");
				printWrite(courses);
				printSummary(courses);
			}
			else{
				System.out.println("No valid result is found in the iteration, please run the program again");
			}
			
			printVerbose.close();
		
	}

	/**
	 * Method that creates textfile in the source directory and displays output for each iteration
	 * @throws FileNotFoundException
	 */
	private void createTextFile() throws FileNotFoundException {
		// writing on a txt file
		printVerbose = new PrintWriter(new File("verbose.txt"));
		printSummary = new PrintWriter(new File("summary.txt"));
		for (int i = 0; i < courses.size(); i++) {
			if (i != courses.size() - 1) {
				printVerbose.write(courses.get(i).getName() + "\t");
			} else {
				printVerbose.write(courses.get(i).getName() + "\n");
			}
		}

		printVerbose.write("----------------------------------------------------------------------------------------------------------------------------------------------------" + "\n");
				
	}

	/**
	 * Method that implements local search using "Most Improving Step" strategy
	 * @param courses -> Arraylist of courses
	 * @return -> true if there is a solution, otherwise returns false
	 */
	private boolean localSearch(ArrayList<Course> courses) {
		
		int randomWalkIteration = 0;
		int randomRestartIteration = 0;
		
		// Random Restart will start here (the program restarts twice if it fails to find a solution in the first try)
		// This ensures that program doesn't "struck" in a search space.
		while(randomRestartIteration < 2){
			
			// Randomly assign value to each variable
			randomVal();
			printWrite(courses);
			
				// Random Walk which iterates 1000 times locally
				// If no result is found, it randomly restarts (changes search space)
				while(randomWalkIteration < 1000 && !satisfyingAssignment(courses)){
					
					// Sets values to variables within domain for local search
					setValuesToDomain();
		
					// Ensures that each all the prerequisites are met along with the condition that each semester can't have more than 3 courses  
					if(satisfyingAssignment(courses)){		
						return true;
					};
					
				randomWalkIteration++;		
			}
			
		 randomRestartIteration++;
	 }
		return false;	
	}
	
/**
 * Method that set the value of each variable within the domain
 */
	private void setValuesToDomain() {

		// The following setters methods set variables to a value within the domain
		//499 must be taken in final semester(7)
		courses.get(16).setSemester(7);
		printWrite(courses);
		
		//492 only offered in summer(4,7)
		courses.get(15).setSemester((ran.nextInt() % 2 == 0) ? 4 : 7); //randomly chooses between 4 and 7
		printWrite(courses);
		
		//490 is never offered in summer
		courses.get(14).setSemester((ran.nextInt() % 2 == 0) ? 5 : 6); // 490 can only be taken in semester 5 and 6 (randomly chosen)
		printWrite(courses);
		
		//462 must be taken after all seven 100 and 200 level classes, which takes at least first 3 semesters to complete
		courses.get(13).setSemester(ran.nextInt((7 - 4) + 1) + 4); // 462 can only be taken in semester 4, 5, 6, 7
		printWrite(courses);
		
		//460 must be taken after all seven 100 and 200 level classes, which takes at least first 3 semesters to complete
		courses.get(12).setSemester(ran.nextInt((7 - 4) + 1) + 4); // 460 can only be taken in semester 4, 5, 6, 7
		printWrite(courses);
		
		//440 must be taken in 5,6,7
		courses.get(11).setSemester(ran.nextInt((7 - 5) + 1) + 5); // 440 can only be taken in semester 5, 6, 7
		printWrite(courses);
		
		//372 must be taken in 4,5,6
		courses.get(10).setSemester(ran.nextInt((6 - 4) + 1) + 4); // 372 can only be taken in semester 4,5,6
		printWrite(courses);
		
		//365 must be taken in 4,5,6,7
		courses.get(9).setSemester(ran.nextInt((7 - 4) + 1) + 4); // 490 can only be taken in semester 4, 5, 6, 7
		printWrite(courses);
	
		//340 must be taken in 4
		courses.get(8).setSemester(ran.nextInt((4 - 4) + 1) + 4); // 340 can only be taken in semester 4
		printWrite(courses);
		
		//311 must be taken in 4,5,6,7
		courses.get(7).setSemester(ran.nextInt((7 - 4) + 1) + 4); // 311 can only be taken in semester 4, 5, 6, 7
		printWrite(courses);
		
		//240 must be taken in 3
		courses.get(6).setSemester(ran.nextInt((3 - 3) + 1) + 3); // 240 can only be taken in semester 3
		printWrite(courses);
		
		//232 must be taken in 3
		courses.get(5).setSemester(ran.nextInt((3 - 3) + 1) + 3); // 232 can only be taken in semester 3
		printWrite(courses);
		
		//215 must be taken in 2
		courses.get(4).setSemester(ran.nextInt((2 - 2) + 1) + 2); // 215 can only be taken in semester 2
		printWrite(courses);
		
		//210 must be taken in 2,3
		courses.get(3).setSemester(ran.nextInt((3 - 2) + 1) + 2); // 210 can only be taken in semester 2, 3
		printWrite(courses);
		
		//141 must be taken in 2
		courses.get(2).setSemester(ran.nextInt((2 - 2) + 1) + 2); // 141 can only be taken in semester 2
		printWrite(courses);
		
		//140 must be taken in 1
		courses.get(1).setSemester(ran.nextInt((1 - 1) + 1) + 1); // 140 can only be taken in semester 1
		printWrite(courses);
		
		//120 must be taken in 1
		courses.get(0).setSemester(ran.nextInt((1 - 1) + 1) + 1); // 120 can only be taken in semester 1
		printWrite(courses);
		
	}

	/**
	 * Method that print out the seven semesters with the course numbers for a given semesters in a text file
	 * @param courses -> ArrayList of courses
	 * @throws FileNotFoundException 
	 */
	private void printSummary(ArrayList<Course> courses) throws FileNotFoundException {
		
		String summer1 = "Summer:" + "\t";
		for(int i = 0; i < courses.size(); i++) {
			if(courses.get(i).getSemester() == 1) {
				summer1 += courses.get(i).getName() + "\t";
			}	
		}
		printSummary.write(summer1 + "\n");
		printSummary.write(""  + "\n");
		System.out.println(summer1);
		System.out.println();
		
		String autumn1 = "Autumn:" + "\t";
		for(int j = 0; j < courses.size(); j++) {
			if(courses.get(j).getSemester() == 2) {
				autumn1 += courses.get(j).getName() + "\t";
			}	
		}
		printSummary.write(autumn1  + "\n");
		printSummary.write(""  + "\n");
		System.out.println(autumn1);
		System.out.println();
	
		
		String spring1 = "Spring:" + "\t";
		for(int k = 0; k < courses.size(); k++) {
			if(courses.get(k).getSemester() == 3) {
				spring1 += courses.get(k).getName() + "\t";
			}	
		}
		printSummary.write(spring1  + "\n");
		printSummary.write(""  + "\n");
		System.out.println(spring1);
		System.out.println();
		
		String summer2 = "Summer:" + "\t";
		for(int l = 0; l < courses.size(); l++) {
			if(courses.get(l).getSemester() == 4) {
				summer2 += courses.get(l).getName() + "\t";
			}	
		}
		printSummary.write(summer2  + "\n");
		printSummary.write(""  + "\n");
		System.out.println(summer2);
		System.out.println();
		
		String autumn2 = "Autumn:" + "\t";
		for(int m = 0; m < courses.size(); m++) {
			if(courses.get(m).getSemester() == 5) {
				autumn2 += courses.get(m).getName() + "\t";
			}	
		}
		printSummary.write(autumn2  + "\n");
		printSummary.write(""  + "\n");
		System.out.println(autumn2);
		System.out.println();
		
		String spring2 = "Spring:" + "\t";
		for(int n = 0; n < courses.size(); n++) {
			if(courses.get(n).getSemester() == 6) {
				spring2 += courses.get(n).getName() + "\t";
			}	
		}
		printSummary.write(spring2  + "\n");
		printSummary.write(""  + "\n");
		System.out.println(spring2);
		System.out.println();
		
		String summer3 = "Summer:" + "\t";
		for(int p = 0; p < courses.size(); p++) {
			if(courses.get(p).getSemester() == 7) {
				summer3 += courses.get(p).getName() + "\t";
			}	
		}
		printSummary.write(summer3  + "\n");
		printSummary.write(""  + "\n");
		System.out.println(summer3);
		System.out.println();
		
		printSummary.close();
	}

	/**
	 * Method that ensures that each semester can't have more than 3 classes
	 * @param courses -> ArrayList of courses
	 * @return -> true if the assignment is satisfied, otherwise return false
	 */
	private boolean satisfyingAssignment(ArrayList<Course> courses) {
		
		int oneCount = 0;
		for(int i = 0; i < courses.size(); i++) {
			if(courses.get(i).getSemester() == 1) {
				oneCount++;
			}
		}
		if(oneCount > 3) {
			return false;
		}
		
		int twoCount = 0;
		for(int j = 0; j < courses.size(); j++) {
			if(courses.get(j).getSemester() == 2) {
				twoCount++;
			}
		}
		if(twoCount > 3) {
			return false;
		}
		
		int threeCount = 0;
		for(int k = 0; k < courses.size(); k++) {
			if(courses.get(k).getSemester() == 3) {
				threeCount++;
			}
		}
		if(threeCount > 3) {
			return false;
		}
		
		
		int fourCount = 0;
		for(int l = 0; l < courses.size(); l++) {
			if(courses.get(l).getSemester() == 4) {
				fourCount++;
			}
		}
		if(fourCount > 3) {
			return false;
		}
		
		int fiveCount = 0;
		for(int m = 0; m < courses.size(); m++) {
			if(courses.get(m).getSemester() == 5) {
				fiveCount++;
			}
		}
		if(fiveCount > 3) {
			return false;
		}
		
		int sixCount = 0;
		for(int n = 0; n < courses.size(); n++) {
			if(courses.get(n).getSemester() == 6) {
				sixCount++;
			}
		}
		if(sixCount > 3) {
			return false;
		}
		
		int sevenCount = 0;
		for(int p = 0; p < courses.size(); p++) {
			if(courses.get(p).getSemester() == 7) {
				sevenCount++;
			}
		}
		if(sevenCount > 3) {
			return false;
		}
		
		return true;
	
		
	}

	/**
	 * Method that prints the verbose mode in the text file
	 * @param courses -> ArrayList of courses
	 */
	private void printWrite(ArrayList<Course> courses) {
		for (int j = 0; j < courses.size(); j++) {
			if (j != courses.size() - 1) {
				printVerbose.write(courses.get(j).getSemester() + "\t");
			} else {
				printVerbose.write(courses.get(j).getSemester() + "\n");
			}
		}
		
	}

	/**
	 * Method that assigns random value to each variable in the range of 1-7, inclusive
	 */
	private void randomVal() {
		for (int j = 0; j < courses.size(); j++) {
			courses.get(j).setSemester(ran.nextInt((MAX_VALUE - MIN_VALUE) + 1) + MIN_VALUE);
		}

	}

	/**
	 * Method that creates Course object for each course
	 */
	private void declareCourses() {
		courses = new ArrayList<Course>();
		ran = new Random();
		m120 = new Course("120");
		courses.add(m120);
		cs140 = new Course("140");
		courses.add(cs140);
		cs141 = new Course("141");
		courses.add(cs141);
		m210 = new Course("210");
		courses.add(m210);
		m215 = new Course("215");
		courses.add(m215);
		cs232 = new Course("232");
		courses.add(cs232);
		cs240 = new Course("240");
		courses.add(cs240);
		cs311 = new Course("311");
		courses.add(cs311);
		cs340 = new Course("340");
		courses.add(cs340);
		cs365 = new Course("365");
		courses.add(cs365);
		cs372 = new Course("372");
		courses.add(cs372);
		cs440 = new Course("440");
		courses.add(cs440);
		cs460 = new Course("460");
		courses.add(cs460);
		cs462 = new Course("462");
		courses.add(cs462);
		cs490 = new Course("490");
		courses.add(cs490);
		cs492 = new Course("492");
		courses.add(cs492);
		cs499 = new Course("499");
		courses.add(cs499);
		lib998 = new Course("998");
		courses.add(lib998);
		lib999 = new Course("999");
		courses.add(lib999);

	}

	/**
	 * Main or driver method
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		Prog340C pc = new Prog340C();
	}

}


		