package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * This class graphs a .txt file and creates Nodes and Edges with suitable
 * parameters March 3rd 2018 - New Edge class is created using the graph
 * Created: Jan 20th 2018, Modified: March 4th 2018 (for creation of Edge
 * object)
 * 
 * @author Abrar Zawed
 */
public class Graph {

	// instance variables
	private static final String DEFAULT = "";
	private BufferedReader br1;
	private BufferedReader br2;
	private String currentLine;
	private String output = "";
	private Scanner sc;
	private String name = "";
	private String val = "";
	private String temp = "";
	private int num = 0;
	private String mnemonic = "";
	private ArrayList<Node> listNode;
	private ArrayList<Edge> listEdge;
	private ArrayList<String> row;
	private ArrayList<String> vertex;
	private ArrayList<String> names;
	private ArrayList<String> columns;
	private Map<String, Node> map;
	private ArrayList<String> newRow;
	private ArrayList<String> newVertex;
	private ArrayList<String> newNames;
	private List<Edge> allEdges;
	private Map<String, Node> allNodes;
	private Node node;
	private Edge edge;
	private ArrayList<Node> nodeArrayList;

	/**
	 * Constructor that graphs a text file
	 * 
	 * @param inputFileName
	 *            -> .txt file
	 */
	public Graph(File inputFileName) {

		map = new HashMap<>();
		listEdge = new ArrayList<Edge>();
		listNode = new ArrayList<Node>();
		allEdges = new ArrayList<Edge>();
		nodeArrayList = new ArrayList<Node>();
		allNodes = new HashMap<String, Node>();
		readFile(inputFileName);

		for (int i = 0; i < listEdge.size(); i++) {
			addEdges(listEdge.get(i).getSourceNode().getMnemonic(), listEdge.get(i).getDestinationNode().getMnemonic(),
					listEdge.get(i).getWeight());
		}

	}

	/**
	 * Method that reads a .txt file in order to create Node and Edge objects
	 * 
	 * @param NewFileName
	 *            -> input .txt file
	 */
	private void readFile(File NewFileName) {
		// create Node
		createNode(NewFileName);
		// create Edge
		createEdge(NewFileName);
	}

	/**
	 * Method that creates Edge using the text file
	 * 
	 * @param newFileName
	 */

	private void createEdge(File newFileName) {
		newRow = new ArrayList<String>();
		newVertex = new ArrayList<String>();
		newNames = new ArrayList<String>();

		try {
			br1 = new BufferedReader(new FileReader(newFileName));
			while ((currentLine = br1.readLine()) != null) {
				sc = new Scanner(currentLine);
				newNames.add(sc.next());
			}

			br1 = new BufferedReader(new FileReader(newFileName));
			currentLine = br1.readLine();
			sc = new Scanner(currentLine);
			sc.next();
			sc.next();
			while ((temp = sc.next()) != null) {
				newRow.add(temp);
				if (!sc.hasNext()) {
					break;
				}
			}

			while ((currentLine = br1.readLine()) != null) {
				sc = new Scanner(currentLine);
				name = sc.next();
				sc.next();
				while ((temp = sc.next()) != null) {
					newVertex.add(temp);
					if (!sc.hasNext()) {
						break;
					}
				}

				for (int i = 0; i < newVertex.size(); i++) {
					if (!newVertex.get(i).equals("~")) {
						edge = new Edge(map.get(name), map.get(newNames.get(i + 1)), newVertex.get(i));
						listEdge.add(edge);
					}
				}

				newVertex.clear();

			}

		} catch (Exception error) {
			error.printStackTrace();
		}

	}

	/**
	 * Method that creates Node using the text file
	 * 
	 * @param newFileName
	 */
	private void createNode(File newFileName) {
		row = new ArrayList<String>();
		vertex = new ArrayList<String>();
		names = new ArrayList<String>();
		columns = new ArrayList<String>();

		try {
			br1 = new BufferedReader(new FileReader(newFileName));
			while ((currentLine = br1.readLine()) != null) {
				sc = new Scanner(currentLine);
				names.add(sc.next());
				sc.next();
				columns.add(sc.next());

			}

			br1 = new BufferedReader(new FileReader(newFileName));
			currentLine = br1.readLine();
			sc = new Scanner(currentLine);
			sc.next();
			sc.next();
			while ((temp = sc.next()) != null) {
				row.add(temp);

				if (!sc.hasNext()) {
					break;
				}
			}

			while ((currentLine = br1.readLine()) != null) {

				sc = new Scanner(currentLine);
				name = sc.next();
				val = sc.next();
				while ((temp = sc.next()) != null) {

					vertex.add(temp);
					if (!sc.hasNext()) {
						break;
					}
				}

				mnemonic = row.get(num++);
				node = new Node(name, mnemonic, val);

				map.put(name, node);
				listNode.add(node);

				output += "Node " + name + "," + " mnemonic " + mnemonic + "," + " value " + val + "\r\n";
				for (int i = 0; i < vertex.size(); i++) {
					if (!vertex.get(i).equals("~")) {
						output += name + " has edge to " + names.get(i + 1) + " labeled " + vertex.get(i) + "\r\n";

					}
				}
				for (int i = 1; i < columns.size(); i++) {
					if (!columns.get(i).equals("~")) {
						output += name + " has edge from " + names.get(i) + " labeled " + columns.get(i) + "\r\n";
					}
				}

				output += "\r\n";
				vertex.clear();
				columns.clear();
				br2 = new BufferedReader(new FileReader(newFileName));
				while ((currentLine = br2.readLine()) != null) {
					sc = new Scanner(currentLine);
					names.add(sc.next());
					sc.next();
					for (int i = 0; i < num; i++) {
						sc.next();
					}
					if (sc.hasNext()) {
						columns.add(sc.next());
					}
				}
			}

		} catch (Exception error) {
			error.printStackTrace();
		}

	}

	/**
	 * Method that creates IntEdge object which is used in Prim's MST
	 * IntEdge that weight as String and converts to int
	 * @param mnemonic1 -> the mnemonic of the source Node
	 * @param mnemonic2 -> the mnemonic of the destination Node
	 * @param weight -> the weight of the Edge in String
	 */
	public void addEdges(String mnemonic1, String mnemonic2, String weight) {
		Node sourceNode = null;
		if (allNodes.containsKey(mnemonic1)) {
			sourceNode = allNodes.get(mnemonic1);
		} else {
			sourceNode = new Node(mnemonic1);
			nodeArrayList.add(sourceNode);
			allNodes.put(mnemonic1, sourceNode);
		}
		Node destinationNode = null;
		if (allNodes.containsKey(mnemonic2)) {
			destinationNode = allNodes.get(mnemonic2);
		} else {
			destinationNode = new Node(mnemonic2);
			nodeArrayList.add(destinationNode);
			allNodes.put(mnemonic2, destinationNode);
		}

		IntEdge edge = new IntEdge(sourceNode, destinationNode, weight);
		allEdges.add(edge);
		sourceNode.addAdjacentNode(edge, destinationNode);
		destinationNode.addAdjacentNode(edge, sourceNode);
	}
	
	public ArrayList<Node> nodeArrayLists() {
		return this.nodeArrayList;
	}

	/**
	 * Simple collection class that hold all value of Nodes 
	 * @return the value of the Node
	 */
	public Collection<Node> getAllNode() {
		return allNodes.values();
	}

	/**
	 * Returns -> String named output that is used in the IO class for
	 * PrintWriter
	 * 
	 * @return String named output that is used in the IO class for PrintWriter
	 */
	public String getOutput() {
		return this.output;
	}

	/**
	 * Returns -> an ArrayList of Node object which was used in the Heap class
	 * to create min-heap
	 * 
	 * @return
	 */
	public ArrayList<Node> getNodeArrayList() {
		return this.listNode;
	}

	/**
	 * Method that clears the output string for next next .txt file
	 */
	public void setDefaultOutput() {
		this.output = DEFAULT;
	}

	/**
	 * Returns -> an ArrayList of Edge object used in MST
	 * 
	 * @return
	 */
	public ArrayList<Edge> getEdgeArrayList() {
		return this.listEdge;
	}

}
