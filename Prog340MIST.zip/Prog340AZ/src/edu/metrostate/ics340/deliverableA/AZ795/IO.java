package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * Class that prints the output of the graphed file
 * Created: Jan 19th 2018
 * @author Abrar Zawed
 *
 */
public class IO {
	
	private String outputFileName;

	/**
	 * Constructor that output a graphed file
	 * @param inputFileName
	 * @param g
	 */
	public IO(File inputFileName, Graph g) {
		displayOutput(inputFileName, g);

	}

	/**
	 * Method that displays the output of the graphed file
	 * @param inputFileName - the original ungraphed file
	 * @param g - Graph object
	 */
	private void displayOutput(File inputFileName, Graph g) {
		outputFileName = inputFileName.getAbsolutePath().substring(0, inputFileName.getAbsolutePath().lastIndexOf('.'));
		outputFileName += "_out.txt";
		try {
			PrintWriter pw = new PrintWriter(new File(outputFileName));
			System.out.println(outputFileName + " is created");
			pw.write(g.getOutput());
			g.setDefaultOutput();
			pw.close();
		} catch (FileNotFoundException e) {
			System.out.println("File is not found");
			e.printStackTrace();
		}

	}

}
