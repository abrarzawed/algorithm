package edu.metrostate.ics340.deliverableA.AZ795;
/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/
import java.util.ArrayList;
import java.util.List;


/**
 * Class that creates Node object with name, mnemonic, and value as parameters
 * @author Abrar Zawed
 * Created: Feb 19th 2018
 *
 */
public class Node {
	
	// instance variables
	private String name;
	private String mnemonic;
	private String val;
	private List<IntEdge> edges = new ArrayList<>();
	private List<Node> adjacentNode = new ArrayList<>();

	/**
	 * 
	 * Constructor that creates a Node object
	 * @param name - Name of the Node
	 * @param mnemonic - Mnemonic of the Node
	 * @param val - Value of the Node
	 */
	public Node(String name, String mnemonic, String val) {
		this.name = name;
		this.mnemonic = mnemonic;
		this.val = val;
	}

	/**
	 * Constructor that creates Node object with only mnemonic
	 * @param mnemonic - the mnemonic of the Node
	 */
	public Node(String mnemonic) {
		this.mnemonic = mnemonic;
	}
	
	/**
	 * Returns the mnemonic of the Node
	 * @return -  the mnemonic of the Node
	 */
	public String getMnemonic() {
		return mnemonic;
	}

	/**
	 * Sets the mnemonic of the Node
	 * @param name - The mnemonic of the Node
	 */
	public void setMnemonic(String mnemonic) {
		this.mnemonic = mnemonic;
	}
	
	/**
	 * Method that add adjacent nodes to an Edge
	 * @param e
	 * @param v
	 */
	public void addAdjacentNode(IntEdge e, Node v) {
		edges.add(e);
		adjacentNode.add(v);
	}
	
	public List<IntEdge> getEdges() {
		return edges;
	}

	/**
	 * Returns the name of the Node
	 * @return -  the name of the Node
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name of the Node
	 * @param name - The name of the Node
	 */
	public void setName(String name) {
		this.name = name;
	}

	

	/**
	 * Returns the vale of the Node
	 * @return -  the value of the Node
	 */
	public String getVal() {
		return val;
	}

	/**
	 * Sets the value of the Node
	 * @param name - The value of the Node
	 */
	public void setVal(String val) {
		this.val = val;
	}

	/**
	 * Returns the name of the Node
	 */
	@Override
	public String toString() {
		return getMnemonic();
	}

}
