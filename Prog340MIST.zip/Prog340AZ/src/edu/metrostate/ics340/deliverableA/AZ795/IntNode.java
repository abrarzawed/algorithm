package edu.metrostate.ics340.deliverableA.AZ795;
/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

/**
 * Class that creates IntNode object with sourceNode, destinationNode, and weight
 * as parameters respectively
 * This class extends Node class via inheritance
 * This class will be used in future to implement Traveling Salesman Problem
 * @author Abrar Zawed 
 * Created: March 5th 2018 
 * Last Modification: March 5th 2018 (for MIST)
 */
public class IntNode extends Node{

	// instance variables
	private int value;
	
	/**
	 * Constructor that generates IntNode object
	 * @param name -> the name of the IntNode object
	 * @param mnemonic
	 * @param val
	 */
	public IntNode(String name, String mnemonic, String val) {
		super(name, mnemonic, val);
		this.value = Integer.parseInt(super.getVal());
	}
	
	/**
	 * Method that returns the integer value of the IntNode
	 * @return
	 */
	public int getValue() {
		return value;
	}
	
	/**
	 * Method that sets the integer value of the IntNode
	 * @return
	 */
	public void setValue(int value) {
		this.value = value;
	}

}
