package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/
/**
 * Class that creates NewNode object with Node object and its value as key
 * Used in (heap + map) data-structure
 * @author Abrar Zawed 
 * Created: March 5th 2018 
 * Last Modification: March 5th 2018 (for MIST)
 */

public class NewNode {
	
	//instance variable
    int weight;
    Node node;
    
    /**
     * Constructor that generates NewNode object
     * @param weight - the weight of the Node object
     * @param node - the Node object itself
     */
    public NewNode(int weight, Node node) {
    	this.weight = weight;
    	this.node = node;
    }

    /**
     * Returns the weight of the NewNode
     * @return
     */
	public int getWeight() {
		return weight;
	}

	/**
	 * Sets the weight of the NewNode
	 * @param weight
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}

	/**
	 * Returns the Node of the NewNode
	 * @return
	 */
	public Node getKey() {
		return node;
	}

	/**
	 * Sets the Node of the NewNode 
	 * @param key
	 */
	public void setKey(Node key) {
		this.node = key;
	}
}
