package edu.metrostate.ics340.deliverableA.AZ795;

/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class that creates a Min-Heap using an ArrayList of Nodes Created: Feb 19th
 * 2018 Modified: March 5th 2018 (in order to create (heap+map) of the min-heap
 * 
 * @author Abrar Zawed
 */

public class Heap {

	// instance variables
	private ArrayList<Node> nodeList;
	private ArrayList<Node> tempNodeList;
	private List<NewNode> allNodes;
	private Map<Node, Integer> nodePosition;
	private Node[] nodes;

	/**
	 * Constructor that creates a Min_heap
	 * 
	 * @param inputFileName
	 *            - The original ungraphed file
	 * @param g
	 *            - Graph object
	 */
	public Heap(File inputFileName, Graph g) {

		// Min-Heap
		System.out.println("Heaps: ");
		System.out.println();

		this.tempNodeList = new ArrayList<>();
		this.nodeList = g.getNodeArrayList();
		for (int i = 0; i < nodeList.size(); i++) {
			heapInsert(nodeList.get(i));
			buildHeap();
			printHeap(tempNodeList);
		}

		// Min-Heap Sort
		System.out.println("Heapsort: ");
		System.out.println();
		nodes = tempNodeList.toArray(new Node[tempNodeList.size()]);
		minSort(nodes);

	}

	/**
	 * Constructor that takes graphed file as parameter and generates Minimum Spanning Tree using Prim's algorithm
	 * @param g
	 */
	public Heap(Graph g) {
		// MIST
		allNodes = new ArrayList<>();
		nodePosition = new HashMap<>();
	}

	/**
	 * Method that inserts a Node to the Heap
	 * 
	 * @param item
	 *            - Node object
	 */
	public void heapInsert(Node item) {
		int i = tempNodeList.size();
		tempNodeList.add(item);
		int parent = parent(i);
		while (parent != -1 && Integer.parseInt(tempNodeList.get(i).getVal()) < Integer
				.parseInt(tempNodeList.get(parent).getVal())) {
			swap(i, parent);
			i = parent;
			parent = parent(i);
		}
	}

	/**
	 * Method that prints a min-heaped Nodes
	 * 
	 * @param listNode
	 *            - min-heaped Nodes
	 */
	private void printHeap(ArrayList<Node> listNode) {
		for (int i = 0; i < listNode.size(); i++) {
			if (i != listNode.size() - 1) {
				System.out.print((i + 1) + ":" + (listNode.get(i)) + ", ");
			} else {
				System.out.print((i + 1) + ":" + (listNode.get(i)) + " ");
			}
		}
		System.out.println("\n");

	}

	/**
	 * Method that builds a heap
	 */
	private void buildHeap() {
		for (int i = (int) (tempNodeList.size() / 2); i >= 0; i--) {
			heapify(i);
		}
	}

	/**
	 * Method that min-heaps an ArrayList of Nodes
	 * 
	 * @param i
	 */
	private void heapify(int i) {
		int l = left(i);
		int r = right(i);
		int smallest = i;
		if (l < tempNodeList.size()
				&& Integer.parseInt(tempNodeList.get(l).getVal()) < Integer.parseInt(tempNodeList.get(i).getVal())) {
			smallest = l;
		}
		if (r < tempNodeList.size() && Integer.parseInt(tempNodeList.get(r).getVal()) < Integer
				.parseInt((tempNodeList.get(smallest).getVal()))) {
			smallest = r;
		}
		if (smallest != i) {
			swap(i, smallest);
			heapify(smallest);
		}
	}

	/**
	 * Method that exchanges two Node object
	 * 
	 * @param i1
	 *            - Node Object
	 * @param i2
	 *            - Node Object
	 */
	private void swap(int i1, int i2) {
		Node temp = tempNodeList.get(i1);
		tempNodeList.set(i1, tempNodeList.get(i2));
		tempNodeList.set(i2, temp);
	}

	/**
	 * Parent of the Node in action
	 * 
	 * @param i
	 * @return - the position of the parent Node
	 */
	private int parent(int i) {
		if (i == 0) {
			return -1;
		}
		return (i - 1) / 2;
	}

	/**
	 * Left child of the Node in action
	 * 
	 * @param i
	 * @return - the position of the left child Node
	 */
	private int left(int i) {
		return 2 * i + 1;
	}

	/**
	 * Right child of the Node in action
	 * 
	 * @param i
	 * @return - the position of the right child Node
	 */
	private int right(int i) {
		return 2 * i + 2;
	}

	/**
	 * Method that extract the Min Node from a heap
	 * 
	 * @return
	 */
	public Node extractMin() {
		if (tempNodeList.size() == 0) {
			return null;
		}
		if (tempNodeList.size() == 1) {
			return tempNodeList.remove(0);
		}
		Node min = tempNodeList.get(0);
		Node last = tempNodeList.remove(tempNodeList.size() - 1);
		tempNodeList.set(0, last);
		heapify(0);
		return min;
	}

	/**
	 * Method that returns that Node with minimum value Does not removes from
	 * the heap
	 * 
	 * @return
	 */
	public Node min() {
		if (tempNodeList.size() == 0) {
			return null;
		}
		return tempNodeList.get(0);
	}

	/**
	 * Method that clears the heap
	 */
	public void clear() {
		tempNodeList.clear();
	}

	/**
	 * Method that checks if a heap is empty
	 * 
	 * @return
	 */
	public boolean isEmpty() {
		return tempNodeList.size() == 0;
	}

	/**
	 * Method that returns the size of a heap in terms of Nodes
	 * 
	 * @return
	 */
	public int size() {
		return tempNodeList.size();
	}

	/**
	 * Checks where the key exists in heap or not
	 */
	public boolean containsData(Node key) {
		return nodePosition.containsKey(key);
	}

	/**
	 * Add key and its weight to the heap
	 */
	public void addNode(int weight, Node key) {
		NewNode node = new NewNode(weight, key);

		allNodes.add(node);
		int size = allNodes.size();
		int current = size - 1;
		int parentIndex = (current - 1) / 2;
		nodePosition.put(node.node, current);

		while (parentIndex >= 0) {
			NewNode parentNode = allNodes.get(parentIndex);
			NewNode currentNode = allNodes.get(current);
			if (parentNode.weight > currentNode.weight) {
				swapNode(parentNode, currentNode);
				updatePositionMap(parentNode.node, currentNode.node, parentIndex, current);
				current = parentIndex;
				parentIndex = (parentIndex - 1) / 2;
			} else {
				break;
			}
		}
	}

	/**
	 * Checks with heap is empty or not
	 */
	public boolean empty() {
		return allNodes.size() == 0;
	}

	/**
	 * Decreases the weight of given key to newWeight
	 */
	public void decreaseWeight(Node data, int newWeight) {
		Integer position = nodePosition.get(data);
		allNodes.get(position).weight = newWeight;
		int parent = (position - 1) / 2;
		while (parent >= 0) {
			if (allNodes.get(parent).weight > allNodes.get(position).weight) {
				swapNode(allNodes.get(parent), allNodes.get(position));
				updatePositionMap(allNodes.get(parent).node, allNodes.get(position).node, parent, position);
				position = parent;
				parent = (parent - 1) / 2;
			} else {
				break;
			}
		}
	}

	/**
	 * Get the weight of given key
	 */
	public Integer getIntWeight(Node key) {
		Integer position = nodePosition.get(key);
		if (position == null) {
			return null;
		} else {
			return allNodes.get(position).weight;
		}
	}

	/**
	 * Returns the min node of the heap
	 */
	public NewNode extractMinNode() {
		int size = allNodes.size() - 1;
		NewNode minNode = new NewNode(allNodes.get(0).weight, allNodes.get(0).node);

		int lastNodeWeight = allNodes.get(size).weight;
		allNodes.get(0).weight = lastNodeWeight;
		allNodes.get(0).node = allNodes.get(size).node;
		nodePosition.remove(minNode.node);
		nodePosition.remove(allNodes.get(0));
		nodePosition.put(allNodes.get(0).node, 0);
		allNodes.remove(size);

		int currentIndex = 0;
		size--;
		while (true) {
			int left = 2 * currentIndex + 1;
			int right = 2 * currentIndex + 2;
			if (left > size) {
				break;
			}
			if (right > size) {
				right = left;
			}
			int smallerIndex = allNodes.get(left).weight <= allNodes.get(right).weight ? left : right;
			if (allNodes.get(currentIndex).weight > allNodes.get(smallerIndex).weight) {
				swapNode(allNodes.get(currentIndex), allNodes.get(smallerIndex));
				updatePositionMap(allNodes.get(currentIndex).node, allNodes.get(smallerIndex).node, currentIndex,
						smallerIndex);
				currentIndex = smallerIndex;
			} else {
				break;
			}
		}
		return minNode;
	}

	/**
	 * Extract min value key from the heap
	 */
	public Node extractMinimum() {
		NewNode node = extractMinNode();
		return node.node;
	}

	/**
	 * Method that exchanges Node objects
	 */
	private void swapNode(NewNode node1, NewNode node2) {
		int weight = node1.weight;
		Node data = node1.node;

		node1.node = node2.node;
		node1.weight = node2.weight;

		node2.node = data;
		node2.weight = weight;
	}

	/**
	 * Method that update the position od Node object in the Map
	 */
	private void updatePositionMap(Node data1, Node data2, int pos1, int pos2) {
		nodePosition.remove(data1);
		nodePosition.remove(data2);
		nodePosition.put(data1, pos1);
		nodePosition.put(data2, pos2);
	}

	/**
	 * Methods that sorts an ArrayList of Node objects into decreasing order
	 * using min-heap
	 * 
	 * @param nodesArrays
	 *            -> ArrayList of Nodes
	 */
	public void minSort(Node[] nodesArrays) {
		int heapSize = nodesArrays.length;
		buildHeap(nodesArrays, heapSize);
		while (heapSize > 1) {
			swap(nodesArrays, 0, heapSize - 1);
			heapSize--;
			heapify(nodesArrays, heapSize, 0);
			for (int i = 0; i < nodesArrays.length; i++) {
				if (i != nodesArrays.length - 1) {
					System.out.print((i + 1) + ":" + nodesArrays[i].getMnemonic() + ", ");
				} else {
					System.out.print((i + 1) + ":" + nodesArrays[i].getMnemonic() + " ");
				}
			}
			System.out.println("\n");
		}

	}

	/**
	 * Method that builds a min-heap
	 * 
	 * @param array
	 *            - Array of Node objects
	 * @param heapSize
	 *            - size of the array
	 */
	private void buildHeap(Node[] array, int heapSize) {
		for (int i = (int) (array.length / 2); i >= 0; i--) {
			heapify(array, heapSize, i);
		}
	}

	/**
	 * Heapify an array of Nodes
	 * 
	 * @param array
	 *            Array of Node objects
	 * @param heapSize
	 *            size of the array
	 * @param i
	 *            - a specific nodes from the array
	 */
	private void heapify(Node[] array, int heapSize, int i) {
		int left = this.left(i);
		int right = this.right(i);
		int smallest;
		if (left < heapSize && Integer.parseInt(array[left].getVal()) < Integer.parseInt((array[i]).getVal()))
			smallest = left;
		else
			smallest = i;
		if (right < heapSize && Integer.parseInt(array[right].getVal()) < Integer.parseInt((array[smallest]).getVal()))
			smallest = right;
		if (smallest != i) {
			swap(array, i, smallest);
			heapify(array, heapSize, smallest);
		}

	}

	/**
	 * Exchanges two Node object
	 * 
	 * @param - array Array of Node objects
	 * @param a - Node
	 * @param b - Node
	 */
	private void swap(Node[] array, int a, int b) {
		Node temp = array[a];
		array[a] = array[b];
		array[b] = temp;

	}
}



