package edu.metrostate.ics340.deliverableA.AZ795;
/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Class that genarates Minimum Spanning Trees using Prim's Algorithm
 * 
 * @author Abrar Zawed Created: March 5th 2018, Last Modification: March 5th
 *         2018 (for MIST)
 */
public class Mist {

	// instance variables
	private int length;
	private ArrayList<IntEdge> result;
	private ArrayList<IntEdge> intEdgeList;
	private ArrayList<Node> listNode;
	private Node startingNode;

	/**
	 * Constructor that generates Minimum Spanning Tree using Prim's Algorithm
	 * 
	 * @param inputFileName
	 *            -> the text file
	 * @param g
	 *            -> the graphed file
	 */
	public Mist(File inputFileName, Graph g) {
		this.listNode = g.nodeArrayLists();
		startingNode = listNode.get(0);
		intEdgeList = MST(g);
		printMist(intEdgeList);

	}

	/**
	 * Method that prints the results of the MIST
	 * 
	 * @param intEdgeList
	 *            -> Arraylist of IntEdge
	 */
	private void printMist(ArrayList<IntEdge> intEdgeList) {

		System.out.print("MST Edges, in order of addition: ");
		for (int i = 0; i < intEdgeList.size(); i++) {

			length += intEdgeList.get(i).getIntWeight();

			if (i != intEdgeList.size() - 1) {
				System.out.print(intEdgeList.get(i).getSourceNode().getMnemonic()
						+ intEdgeList.get(i).getDestinationNode().getMnemonic() + ", ");
			} else {
				System.out.print(intEdgeList.get(i).getSourceNode().getMnemonic()
						+ intEdgeList.get(i).getDestinationNode().getMnemonic());
			}
		}
		System.out.println("\n");

		System.out.print("MST length: " + length);
		System.out.println("\n");

	}

	/**
	 * Method that returns an ArrayList of IntEdge using Heap class
	 * 
	 * @param g
	 * @return
	 */
	public ArrayList<IntEdge> MST(Graph g) {

		result = new ArrayList<>();

		// Creates min-heap using the graphed file
		Heap minHeap = new Heap(g);

		// Map that generates MINIMUM weight from a particular Node
		Map<Node, IntEdge> nodeToEdge = new HashMap<>();

		// Set the value of every Node to Integer.MAX_VALUE (infinity) at the
		// beginning of MST
		for (Node node : g.getAllNode()) {
			minHeap.addNode(Integer.MAX_VALUE, node);
		}

		// Decrease the value of start Node in (heap + map) to 0
		minHeap.decreaseWeight(startingNode, 0);

		while (!minHeap.empty()) {
			Node current = minHeap.extractMinimum();

			IntEdge spanningTreeEdge = nodeToEdge.get(current);
			if (spanningTreeEdge != null) {
				result.add(spanningTreeEdge);
			}

			// Iterate through all the adjacent Nodes
			for (IntEdge edge : current.getEdges()) {
				Node adjacent = getNodeForEdge(current, edge);
				if (minHeap.containsData(adjacent) && minHeap.getIntWeight(adjacent) > edge.getIntWeight()) {
					minHeap.decreaseWeight(adjacent, edge.getIntWeight());
					nodeToEdge.put(adjacent, edge);
				}
			}
		}
		return result;
	}

	/**
	 * Method that returns the Node associated with an Edge
	 * 
	 * @return
	 */
	private Node getNodeForEdge(Node n, Edge e) {
		return e.getSourceNode().equals(n) ? e.getDestinationNode() : e.getSourceNode();
	}

}
