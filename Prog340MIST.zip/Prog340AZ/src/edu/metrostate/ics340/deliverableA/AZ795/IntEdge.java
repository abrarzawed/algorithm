package edu.metrostate.ics340.deliverableA.AZ795;
/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

/**
 * Class that creates IntEdge object with sourceNode, destinationNode, and weight
 * as parameters respectively
 * 
 * @author Abrar Zawed
 * Created: March 5th 2018 
 * Last Modification: March 5th 2018 (for MIST)
 * 
 */

public class IntEdge extends Edge {
	
	//instance variables
	private int intWeight;

	/**
	 * Constructor that creates IntEdge object
	 * @param sourceNode -> the source Node of the IntEdge object
	 * @param destinationNode -> the destination Node of the IntEdge object
	 * @param weight -> the weight of the IntEdge object
	 */
	public IntEdge(Node sourceNode, Node destinationNode, String weight) {
		super(sourceNode, destinationNode, weight);
		this.intWeight = Integer.parseInt(getWeight());
	}

	/**
	 * toString of the IntEdge object
	 */
	@Override
	public String toString() {
		return "Source: " + super.getSourceNode().getMnemonic() + ", " + "Destination: "
				+ super.getDestinationNode().getMnemonic() + ", " + "Weight: " + this.getIntWeight();
	}
	
	/**
	 * Returns the weight of the IntEdge in int
	 * @return -> the weight of the IntEdge in int
	 */

	public int getIntWeight() {
		return intWeight;
	}

	/**
	 * Sets the weight of IntEdge in int
	 * @param intWeight -> the weight of the IntEdge
	 */
	public void setIntWeight(int intWeight) {
		this.intWeight = intWeight;
	}
}
