package edu.metrostate.ics340.deliverableA.AZ795;
/*********************************************************************************
 * Copyright (c) 2018 Abrar Zawed 
 * Written for ICS 340 (Algorithm and Data Structures)
 * All rights reserved.
**********************************************************************************/

/**
 * Class that creates Edge object with sourceNode, destinationNode, and weight
 * as parameters respectively
 * 
 * @author Abrar Zawed Created: March 5th 2018, Last Modification: March 5th
 *         2018 (for MIST)
 */

public class Edge {

	//instance variables
	private Node sourceNode;
	private Node destinationNode;
	private String weight;

	/**
	 * Constructor that creates Edge object with sourceNode, destinationNode,
	 * and weight as parameters respectively
	 * 
	 * @param sourceNode
	 *            -> the source Node object
	 * @param destinationNode
	 *            -> the destination Node object
	 * @param weight
	 *            -> the weight of the edge
	 */
	public Edge(Node sourceNode, Node destinationNode, String weight) {
		this.weight = weight;
		this.sourceNode = sourceNode;
		this.destinationNode = destinationNode;
	}

	/**
	 * Returns the source Node of the Edge object
	 * 
	 * @return -> the source Node of the Edge object
	 */
	public Node getSourceNode() {
		return sourceNode;
	}

	/**
	 * Sets the source Node of the Edge object
	 */
	public void setSourceNode(Node sourceNode) {
		this.sourceNode = sourceNode;
	}

	/**
	 * Returns the destination Node of the Edge object
	 * 
	 * @return -> the destination Node of the Edge object
	 */
	public Node getDestinationNode() {
		return destinationNode;
	}

	/**
	 * Sets destination Node of the Edge object
	 */
	public void setDestinationnode(Node destinationnode) {
		this.destinationNode = destinationnode;
	}

	/**
	 * Returns the weight of the Edge object
	 * 
	 * @return -> the weight of the Edge object
	 */
	public String getWeight() {
		return weight;
	}

	/**
	 * Sets the weight of the Edge object
	 * 
	 * @param weight
	 *            -> the weight of the Edge object
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}

}
